package com.skygh.motionline

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * عکس رو به هزاران خط کوتاه (روی لبه‌ها) تبدیل می‌کنه.
 * هر خط یه ذره‌ی فنری‌یه که با لمس به سمت انگشت کشیده می‌شه.
 */
class MotionLineView(context: Context) : View(context) {

    private class Model(
        val n: Int, val imgW: Int, val imgH: Int,
        val nx: FloatArray, val ny: FloatArray,
        val ca: FloatArray, val sa: FloatArray,
        val groupColors: IntArray, val groupIdx: Array<IntArray>
    )

    private val dp = resources.displayMetrics.density
    private val paperColor = Color.rgb(244, 243, 249)
    private val inkColor = Color.rgb(52, 40, 102)
    private val accentColor = Color.rgb(226, 82, 76)

    var colorMode = false
    var detail = 0.5f
    var onTouchStart: (() -> Unit)? = null

    private var model: Model? = null
    private var allIdx = IntArray(0)
    private var hx = FloatArray(0)
    private var hy = FloatArray(0)
    private var x = FloatArray(0)
    private var y = FloatArray(0)
    private var vx = FloatArray(0)
    private var vy = FloatArray(0)
    private var ph = FloatArray(0)
    private var kk = FloatArray(0)
    private var buf = FloatArray(0)
    private var lenBase = 5f
    private var source: Bitmap? = null
    private var generation = 0

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = 1.3f * dp
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * dp
        color = accentColor
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accentColor }

    private var touching = false
    private var tx = 0f
    private var ty = 0f
    private var sx = 0f
    private var sy = 0f
    private var pull = 0f
    private val t0 = System.nanoTime()

    fun setImage(bmp: Bitmap, scatter: Boolean = true, done: ((Boolean) -> Unit)? = null) {
        source = bmp
        val gen = ++generation
        val d = detail
        val dm = resources.displayMetrics
        val shortestDp = min(dm.widthPixels, dm.heightPixels) / dp
        val maxBase = if (shortestDp < 600) 3200 else 5600
        Thread {
            val m = try { analyze(bmp, d, maxBase) } catch (e: Throwable) { null }
            post {
                if (gen != generation) return@post
                if (m != null) applyModel(m, scatter)
                done?.invoke(m != null)
            }
        }.start()
    }

    fun rebuild(done: ((Boolean) -> Unit)? = null) {
        source?.let { setImage(it, false, done) }
    }

    fun snapshot(): Bitmap? {
        if (width == 0 || height == 0) return null
        val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        draw(Canvas(b))
        return b
    }

    // ---------- پردازش تصویر ----------

    private fun blur(s: FloatArray, w: Int, h: Int) {
        val t = FloatArray(s.size)
        for (yy in 0 until h) for (xx in 0 until w) {
            var sum = 0f; var c = 0
            for (k in -1..1) { val q = xx + k; if (q in 0 until w) { sum += s[yy * w + q]; c++ } }
            t[yy * w + xx] = sum / c
        }
        for (yy in 0 until h) for (xx in 0 until w) {
            var sum = 0f; var c = 0
            for (k in -1..1) { val q = yy + k; if (q in 0 until h) { sum += t[q * w + xx]; c++ } }
            s[yy * w + xx] = sum / c
        }
    }

    private fun analyze(src: Bitmap, detail: Float, maxBase: Int): Model? {
        val sc = min(1f, 440f / max(src.width, src.height))
        val w = max(8, (src.width * sc).roundToInt())
        val h = max(8, (src.height * sc).roundToInt())
        val small = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(small).apply {
            drawColor(Color.WHITE)
            drawBitmap(src, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        val pix = IntArray(w * h)
        small.getPixels(pix, 0, w, 0, 0, w, h)
        small.recycle()

        val g = FloatArray(w * h)
        for (i in 0 until w * h) {
            val c = pix[i]
            g[i] = 0.299f * ((c shr 16) and 255) + 0.587f * ((c shr 8) and 255) + 0.114f * (c and 255)
        }
        blur(g, w, h); blur(g, w, h)

        val mag = FloatArray(w * h)
        val gxA = FloatArray(w * h)
        val gyA = FloatArray(w * h)
        for (yy in 1 until h - 1) for (xx in 1 until w - 1) {
            val i = yy * w + xx
            val a = g[i - w - 1]; val b = g[i - w]; val c = g[i - w + 1]
            val d = g[i - 1]; val f = g[i + 1]
            val p = g[i + w - 1]; val q = g[i + w]; val r = g[i + w + 1]
            val gx = (c + 2 * f + r) - (a + 2 * d + p)
            val gy = (p + 2 * q + r) - (a + 2 * b + c)
            mag[i] = sqrt(gx * gx + gy * gy); gxA[i] = gx; gyA[i] = gy
        }

        val keep = 0.05f + 0.17f * detail
        val sorted = mag.copyOf(); sorted.sort()
        val ti = (sorted.size * (1 - keep)).toInt().coerceIn(0, sorted.size - 1)
        val thr = max(10f, sorted[ti])
        var cc = 0
        for (v in mag) if (v > thr) cc++
        if (cc < 30) return null
        val cand = IntArray(cc)
        var k = 0
        for (i in mag.indices) if (mag[i] > thr) cand[k++] = i

        val n = min(cc, (maxBase * (0.6f + 0.8f * detail)).toInt())
        val rnd = Random(System.nanoTime())
        for (i in 0 until n) {
            val j = i + rnd.nextInt(cc - i)
            val t = cand[i]; cand[i] = cand[j]; cand[j] = t
        }

        val nx = FloatArray(n); val ny = FloatArray(n)
        val ca = FloatArray(n); val sa = FloatArray(n)
        val groups = HashMap<Int, ArrayList<Int>>()
        val order = ArrayList<Int>()
        for (i in 0 until n) {
            val id = cand[i]
            nx[i] = (id % w).toFloat(); ny[i] = (id / w).toFloat()
            val ang = atan2(gyA[id], gxA[id]) + (PI / 2).toFloat()
            ca[i] = cos(ang); sa[i] = sin(ang)
            val c = pix[id]
            var cr = ((c shr 16) and 255).toFloat()
            var cg = ((c shr 8) and 255).toFloat()
            var cb = (c and 255).toFloat()
            val lum = (0.299f * cr + 0.587f * cg + 0.114f * cb) / 255f
            if (lum > 0.6f) { val f = 0.6f / lum; cr *= f; cg *= f; cb *= f }
            val key = Color.rgb(
                min(255, (cr / 48f).roundToInt() * 48),
                min(255, (cg / 48f).roundToInt() * 48),
                min(255, (cb / 48f).roundToInt() * 48)
            )
            groups.getOrPut(key) { order.add(key); ArrayList() }.add(i)
        }
        val gc = IntArray(order.size) { order[it] }
        val gi = Array(order.size) { groups[order[it]]!!.toIntArray() }
        return Model(n, w, h, nx, ny, ca, sa, gc, gi)
    }

    private fun applyModel(m: Model, scatter: Boolean) {
        val oldX = x; val oldY = y
        val oldN = model?.n ?: 0
        model = m
        val n = m.n
        hx = FloatArray(n); hy = FloatArray(n)
        x = FloatArray(n); y = FloatArray(n)
        vx = FloatArray(n); vy = FloatArray(n)
        ph = FloatArray(n) { Random.nextFloat() * 2f * PI.toFloat() }
        kk = FloatArray(n) { 0.035f + Random.nextFloat() * 0.05f }
        allIdx = IntArray(n) { it }
        buf = FloatArray(n * 4)
        layoutHome()
        val w = width.toFloat(); val h = height.toFloat()
        for (i in 0 until n) {
            if (!scatter && oldN > 0) {
                val j = i % oldN; x[i] = oldX[j]; y[i] = oldY[j]
            } else {
                val a = Random.nextFloat() * 2f * PI.toFloat()
                val r = max(w, h) * (0.55f + Random.nextFloat() * 0.4f)
                x[i] = w / 2 + cos(a) * r; y[i] = h / 2 + sin(a) * r
            }
        }
        invalidate()
    }

    private fun layoutHome() {
        val m = model ?: return
        if (width == 0 || height == 0) return
        val top = 72 * dp; val bottom = 112 * dp; val side = 20 * dp
        val aw = width - 2 * side; val ah = height - top - bottom
        val s = min(aw / m.imgW, ah / m.imgH)
        val ox = (width - m.imgW * s) / 2
        val oy = top + (ah - m.imgH * s) / 2
        lenBase = (s / dp * 1.7f).coerceIn(3f, 9f) * dp
        for (i in 0 until m.n) { hx[i] = ox + m.nx[i] * s; hy[i] = oy + m.ny[i] * s }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutHome()
    }

    // ---------- انیمیشن ----------

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(paperColor)
        val m = model
        if (m != null) {
            val t = (System.nanoTime() - t0) / 1e9f
            pull += ((if (touching) 1f else 0f) - pull) * (if (touching) 0.08f else 0.05f)
            sx += (tx - sx) * 0.22f; sy += (ty - sy) * 0.22f
            val rr = max(width, height) * 0.3f
            val r2 = rr * rr
            val gx = (sx - width / 2f) * 0.04f * pull
            val gy = (sy - height / 2f) * 0.04f * pull
            val wob = 1.1f * dp
            for (i in 0 until m.n) {
                var px = hx[i] + sin(t * 1.3f + ph[i]) * wob + gx
                var py = hy[i] + cos(t * 1.1f + ph[i] * 1.7f) * wob + gy
                if (pull > 0.001f) {
                    val dx = sx - px; val dy = sy - py
                    val inf = exp(-(dx * dx + dy * dy) / r2) * 0.82f * pull
                    px += dx * inf - dy * inf * 0.18f
                    py += dy * inf + dx * inf * 0.18f
                }
                vx[i] = (vx[i] + (px - x[i]) * kk[i]) * 0.84f
                vy[i] = (vy[i] + (py - y[i]) * kk[i]) * 0.84f
                x[i] += vx[i]; y[i] += vy[i]
            }
            if (colorMode) {
                for (g in m.groupIdx.indices) drawGroup(canvas, m, m.groupIdx[g], m.groupColors[g])
            } else {
                drawGroup(canvas, m, allIdx, inkColor)
            }
            if (pull > 0.02f) {
                val a = (pull * 230).toInt().coerceIn(0, 255)
                ringPaint.alpha = a; dotPaint.alpha = a
                canvas.drawCircle(sx, sy, (14f + sin(t * 4f) * 2f) * dp, ringPaint)
                canvas.drawCircle(sx, sy, 3f * dp, dotPaint)
            }
        }
        postInvalidateOnAnimation()
    }

    private fun drawGroup(c: Canvas, m: Model, idx: IntArray, color: Int) {
        var k = 0
        val spThr = 0.9f * dp
        val maxStretch = 16f * dp
        for (i in idx) {
            val sp = sqrt(vx[i] * vx[i] + vy[i] * vy[i])
            var cx = m.ca[i]; var cy = m.sa[i]
            if (sp > spThr) { cx = vx[i] / sp; cy = vy[i] / sp }
            val len = (lenBase + min(sp * 1.6f, maxStretch)) * 0.5f
            buf[k++] = x[i] - cx * len; buf[k++] = y[i] - cy * len
            buf[k++] = x[i] + cx * len; buf[k++] = y[i] + cy * len
        }
        linePaint.color = color
        c.drawLines(buf, 0, k, linePaint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                tx = e.x; ty = e.y
                if (pull < 0.05f) { sx = tx; sy = ty }
                touching = true
                onTouchStart?.invoke()
            }
            MotionEvent.ACTION_MOVE -> { tx = e.x; ty = e.y }
            MotionEvent.ACTION_UP -> { touching = false; performClick() }
            MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }
}
