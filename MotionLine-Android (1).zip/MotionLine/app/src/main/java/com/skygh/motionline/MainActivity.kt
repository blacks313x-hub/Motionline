package com.skygh.motionline

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.sin

class MainActivity : Activity() {

    private val ink = Color.rgb(52, 40, 102)
    private val ink2 = Color.rgb(110, 104, 140)
    private val surface = Color.rgb(252, 251, 255)
    private val lineC = Color.rgb(222, 220, 232)
    private val segBg = Color.rgb(234, 232, 242)
    private val accent = Color.rgb(226, 82, 76)
    private val accentInk = Color.rgb(255, 247, 245)

    private lateinit var view: MotionLineView
    private lateinit var hint: TextView
    private lateinit var segInk: TextView
    private lateinit var segColor: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        view = MotionLineView(this)
        root.addView(view, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // هدر
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(22), dp(16), dp(22), 0)
        }
        val title = TextView(this).apply {
            text = "موشن‌لاین."
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(ink)
        }
        hint = TextView(this).apply {
            text = "انگشتت رو روی صفحه نگه دار"
            textSize = 13f
            setTextColor(ink2)
            gravity = Gravity.END
        }
        header.addView(title, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
        header.addView(hint, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        root.addView(header, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.TOP))

        // داک پایین
        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat(); setColor(surface); setStroke(dp(1), lineC)
            }
            elevation = dp(6).toFloat()
        }
        val pick = pill("+ عکس", accent, accentInk)
        pick.setOnClickListener { pickImage() }

        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            background = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(segBg) }
        }
        segInk = segButton("جوهری")
        segColor = segButton("رنگی")
        seg.addView(segInk, LinearLayout.LayoutParams(WRAP_CONTENT, dp(38)))
        seg.addView(segColor, LinearLayout.LayoutParams(WRAP_CONTENT, dp(38)))
        segInk.setOnClickListener { setMode(false) }
        segColor.setOnClickListener { setMode(true) }
        setMode(false)

        val seek = SeekBar(this).apply {
            max = 20; progress = 10
            progressTintList = ColorStateList.valueOf(ink)
            thumbTintList = ColorStateList.valueOf(ink)
            progressBackgroundTintList = ColorStateList.valueOf(lineC)
            contentDescription = "جزئیات"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {
                    view.detail = (s?.progress ?: 10) / 20f
                    view.rebuild { ok -> if (!ok) toast("با این جزئیات خطی پیدا نشد، بیشترش کن") }
                }
            })
        }

        val save = pill("⤓", segBg, ink).apply { textSize = 20f; contentDescription = "ذخیره" }
        save.setOnClickListener { saveImage() }

        dock.addView(pick, LinearLayout.LayoutParams(WRAP_CONTENT, dp(44)))
        dock.addView(seg, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { marginStart = dp(6) })
        dock.addView(seek, LinearLayout.LayoutParams(0, dp(44), 1f))
        dock.addView(save, LinearLayout.LayoutParams(dp(44), dp(44)))

        root.addView(dock, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(12), 0, dp(12), dp(16))
        })
        setContentView(root)

        view.onTouchStart = { hint.animate().alpha(0f).setDuration(300).start() }
        view.setImage(makeDemo(), true)
    }

    private fun pill(label: String, bg: Int, fg: Int) = TextView(this).apply {
        text = label
        setTextColor(fg)
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(16), 0, dp(16), 0)
        val shape = GradientDrawable().apply { cornerRadius = dp(22).toFloat(); setColor(bg) }
        background = RippleDrawable(ColorStateList.valueOf(Color.argb(40, 52, 40, 102)), shape, null)
        isClickable = true; isFocusable = true
    }

    private fun segButton(label: String) = TextView(this).apply {
        text = label
        textSize = 14f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(12), 0, dp(12), 0)
        isClickable = true; isFocusable = true
    }

    private fun setMode(color: Boolean) {
        view.colorMode = color
        for ((tv, on) in listOf(segInk to !color, segColor to color)) {
            tv.setTextColor(if (on) ink else ink2)
            tv.background = if (on) GradientDrawable().apply {
                cornerRadius = dp(19).toFloat(); setColor(surface)
            } else null
            tv.elevation = if (on) dp(1).toFloat() else 0f
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- انتخاب عکس ----------

    private fun pickImage() {
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(Intent.createChooser(i, "انتخاب عکس"), REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        toast("دارم خط‌هاش رو می‌کشم…")
        Thread {
            val bmp = decode(uri)
            runOnUiThread {
                if (bmp == null) toast("این فایل باز نشد، یه عکس دیگه امتحان کن")
                else view.setImage(bmp, true) { ok ->
                    if (!ok) toast("توی این عکس خط کافی پیدا نشد")
                }
            }
        }.start()
    }

    private fun decode(uri: Uri): Bitmap? = try {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { d, info, _ ->
            d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > 1200) {
                val f = 1200f / m
                d.setTargetSize(
                    (info.size.width * f).toInt().coerceAtLeast(1),
                    (info.size.height * f).toInt().coerceAtLeast(1)
                )
            }
        }
    } catch (e: Exception) { null }

    // ---------- ذخیره در گالری ----------

    private fun saveImage() {
        val bmp = view.snapshot() ?: return
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "motionline_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/MotionLine")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException()
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            toast("توی گالری ذخیره شد")
        } catch (e: Exception) {
            toast("ذخیره نشد")
        }
    }

    // ---------- تصویر نمونه ----------

    private fun makeDemo(): Bitmap {
        val b = Bitmap.createBitmap(640, 440, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.drawColor(Color.rgb(244, 242, 238))
        p.color = Color.rgb(43, 36, 80); c.drawCircle(430f, 150f, 70f, p)
        p.color = Color.WHITE; c.drawCircle(452f, 132f, 62f, p)
        p.color = Color.rgb(58, 49, 112)
        c.drawPath(Path().apply {
            moveTo(0f, 440f); lineTo(150f, 230f); lineTo(240f, 320f); lineTo(360f, 190f)
            lineTo(520f, 360f); lineTo(640f, 280f); lineTo(640f, 440f); close()
        }, p)
        p.color = Color.rgb(244, 242, 238)
        c.drawPath(Path().apply {
            moveTo(330f, 225f); lineTo(360f, 190f); lineTo(392f, 226f); lineTo(372f, 218f)
            lineTo(358f, 232f); lineTo(344f, 220f); close()
        }, p)
        p.color = Color.rgb(43, 36, 80); p.style = Paint.Style.STROKE; p.strokeWidth = 5f
        for (k in 0 until 3) {
            val path = Path()
            var xx = 40f
            while (xx < 600f) {
                val yy = 395f + k * 16 + sin(xx / 28f + k) * 5f
                if (xx == 40f) path.moveTo(xx, yy) else path.lineTo(xx, yy)
                xx += 4f
            }
            c.drawPath(path, p)
        }
        p.style = Paint.Style.FILL
        for (k in 0 until 5) c.drawCircle(90f + k * 38, 90f + sin(k.toFloat()) * 14f, 4f, p)
        return b
    }

    companion object { private const val REQ_PICK = 42 }
}
